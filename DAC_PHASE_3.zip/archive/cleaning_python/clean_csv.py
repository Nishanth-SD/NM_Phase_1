import pandas as pd
import numpy as np

'''Reading the data set using Pandas'''

df = pd.read_csv(r"../country_vaccinations.csv")

'''Now extracting some basic information from the dataset'''

print("The first 5 entries in the set")
print(df.head())
print("\n\nOverall information of the file")
print(df.info())
print("\n\nNull information in the file")
print(df.isnull().sum())

'''Now removing the rows that have null values in it'''

print("\n\nRemoving rows with null values")

df.dropna(inplace=True)

df = df.reset_index(drop=True)

print("Removed")

print("Saving the cleaned CSV in a new folder named /cleaned_csv")

df.to_csv(r"../cleaned_csv/preprocessed_country_vaccination.csv",index=False)

'''Now creating a new CSV to store the Vaccines used in a country'''

columns_of_interest = ['iso_code','vaccines']
selected_columns_df = df[columns_of_interest]
unique_values_df = selected_columns_df.drop_duplicates()
unique_values_df = unique_values_df.reset_index(drop=True)

print("Created a helping dataset to know about the vaccines used in each county...")

unique_values_df.to_csv(r"../cleaned_csv/vacc.csv")



